### --- Test setup ---

if(FALSE) {
  ## Not really needed, but can be handy when writing tests
  library("RUnit")
  library("nmRPro")
}

######## putrescine case ######
td = 19478; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_09/putrescine/nmr/bmse000109/1H/fid", "rb");
fid = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

nmrData<-new("NmrData")
nmrData@fid<-z
nmrData@Acqu@nbOfPoints=19478
nmrData@Acqu@spectralWidth=12.9911091032519;#ppm (SW)
nmrData@Acqu@transmitterFreq=499.842349248;# MHz (SF1)
nmrData@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file
nmrData@Acqu@dspFirmware=20 # (DSPFVS)
N=nmrData@Acqu@nbOfPoints;
freqOfZero=499.84# MHz (SF)
dw=1/(2*nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq);
hzperpt=nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq/N;
ppmperpt=nmrData@Acqu@spectralWidth/N;
sw_h=nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq;
offset=(nmrData@Acqu@transmitterFreq- freqOfZero) * 1.0e06 + (nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq ) / 2.0;
##############

### --- Test functions ---

test.XiRockeBLCalculation <- function()
{
  # scenario where without zero filling
  nmrDataNew<-fourierTransform(groupDelayCorr(nmrData))
  test<-XiRockeBLCalculation(Re(nmrDataNew@Proc@data));
}

test.calculateBL.GOWI <- function()
{
  # scenario where without zero filling
  nmrDataNew<-fourierTransform(groupDelayCorr(nmrData))
  test<-calculateBL.GOWI(Re(nmrDataNew@Proc@data),binSize=32,windowWidth=60,sdWeight=4);
}

test.calculateBL.TOPHAT <- function()
{
  # scenario where without zero filling
  nmrDataNew<-fourierTransform(groupDelayCorr(nmrData))
  test<-calculateBL.tophat(Re(nmrDataNew@Proc@data),100);
  return(test)
}
