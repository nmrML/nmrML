### --- Test setup ---

if(FALSE) {
  ## Not really needed, but can be handy when writing tests
  library("RUnit")
  library("nmRPro")
}

######## putrescine case ######
td = 19478; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_09/putrescine/nmr/bmse000109/1H/fid", "rb");
fid = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

nmrData<-new("NmrData")
nmrData@fid<-z
nmrData@Acqu@nbOfPoints=19478
nmrData@Acqu@spectralWidth=12.9911091032519;#ppm (SW)
nmrData@Acqu@transmitterFreq=499.842349248;# MHz (SF1)
nmrData@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file
nmrData@Acqu@dspFirmware=20 # (DSPFVS)
N=nmrData@Acqu@nbOfPoints;
freqOfZero=499.84# MHz (SF)
dw=1/(2*nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq);
hzperpt=nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq/N;
ppmperpt=nmrData@Acqu@spectralWidth/N;
sw_h=nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq;
offset=(nmrData@Acqu@transmitterFreq- freqOfZero) * 1.0e06 + (nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq ) / 2.0;
##############

###### case 

######## putrescine case ######
td = 19478; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_09/putrescine/nmr/bmse000109/1H/fid", "rb");
fid = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

nmrData2<-new("NmrData")
nmrData2@fid<-z
nmrData2@Acqu@nbOfPoints=19478
nmrData2@Acqu@spectralWidth=12.9911091032519;#ppm (SW)
nmrData2@Acqu@transmitterFreq=499.842349248;# MHz (SF1)
nmrData2@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file
nmrData2@Acqu@dspFirmware=20 # (DSPFVS)

### --- Test functions ---

test.groupDelayCorr <- function()
{
  # scenario where without zero filling
  mnrDataNew<-groupDelayCorr(nmrData)
  plot(Re(mnrDataNew@Proc@data),type='l')
  
  # scenario where with zero filling
  zeroFilledData<-zeroFill(nmrData,1000);
  nmrDataNew<-groupDelayCorr(zeroFilledData)
  
  plot(Re(mnrDataNew@Proc@data),type='l')
  
  # TODO scenario when DECIM is used and there is not group delay (e.g. aminobenzoic)
  # In this case there will be no leftshift and this value will remain 0
  # however, there is a set of points in the beginnig of the FID that need to be removed...
  
  

  
  
  return(nmrDataNew)
}

# it is working
# TODO write a proper test 
test.apodization <- function(){
  # exponential with no previous preprocessing and default parameters
  nmrDataApo<-apodization(nmrData)
  
  # exponential with no previous preprocessing
  nmrDataApo<-apodization(nmrData,lb=2,method="EXP")
  
  # exponential with previous preprocessing
  nmrDataApo<-apodization(zeroFill(nmrData,1000),lb=2,method="EXP")
  
  return (nmrDataApo)
}

# TODO write a proper test 
test.fourierTransform <- function(){
  # exponential with no previous preprocessing
  spectra<-fourierTransform(nmrData)
  
  # exponential with previous preprocessing
  spectra<-fourierTransform(groupDelayCorr(nmrData))
  
  return (spectra)
}

# TODO write a proper test 
test.phaseCorr <- function(){
  # exponential with no previous preprocessing
  spectra<-fourierTransform(nmrData)
  
  # exponential with previous preprocessing
  spectra<-fourierTransform(groupDelayCorr(nmrData))
  spectra@Proc@referencePoint=2.055
  spectraCorr<-phaseCorr(spectra,zeroOrder=12,firstOrder=-255,pivot=0)
  checkTrue((spectraCorr@Proc@pivotPointPPM< 1e-3 && spectraCorr@Proc@pivotPointPPM> -1e-3),msg="pivot point incorrectly set")
  
  return (spectraCorr)
}

# TODO write a proper test 
test.baselineCorr <- function(){
    
  # exponential with previous preprocessing
  spectra<-phaseCorr(fourierTransform(groupDelayCorr(nmrData)),zeroOrder=15,firstOrder=-135,pivot=0)
  
  spectraCorr<-baselineCorr(spectra)
  
  spectraCorr<-baselineCorr(spectra,method="TOPHAT")
  
  return (spectraCorr)
}
