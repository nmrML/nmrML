library(nmRPro)
library(RGtk2)
library(playwith)
playwith()
######## dibenzofuran 13C - working ######
td = 65536; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_29/dibenzofuran/nmr/bmse000548/13C/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "big");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

dibenzofuran<-new("NmrData")
dibenzofuran@fid<-z
dibenzofuran@Acqu@nbOfPoints=td
dibenzofuran@Acqu@spectralWidth=241.074964854309;#ppm (SW)
dibenzofuran@Acqu@transmitterFreq=125.69961514396;# MHz (SFO1)
#dibenzofuran@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
dibenzofuran@Acqu@dspFirmware=10 # (DSPFVS)
dibenzofuran@Acqu@decim=6 # (DECIM)

print("raw data")
plot.spectrum(dibenzofuran)
1.13e-3/getDwell(dibenzofuran)
dibenzofuran@Proc@leftShift=68

print("group delay correction")
plot.spectrum(groupDelayCorr(dibenzofuran))
dibenzofuranFold<-foldSpectrum(fourierTransform(apodization(groupDelayCorr(dibenzofuran))),36.3,inversion=FALSE)
plot.spectrum(dibenzofuranFold,xlim=range(78,81))
plot.spectrum(phaseCorr(dibenzofuranFold,zeroOrder=20,pivot=79,firstOrder=250))
plot.spectrum(phaseCorr(dibenzofuranFold,zeroOrder=20,pivot=79,firstOrder=250),xlim=range(75,160))
dibenzofuranNorm<-phaseCorr(dibenzofuranFold,zeroOrder=20,pivot=79,firstOrder=250)
dibenzofuranNorm@Proc@data=complex(real=Re(dibenzofuranNorm@Proc@data)/(max(Re(dibenzofuranNorm@Proc@data))-min(Re(dibenzofuranNorm@Proc@data))),imaginary=Im(dibenzofuranNorm@Proc@data)/(max(Im(dibenzofuranNorm@Proc@data))-min(Im(dibenzofuranNorm@Proc@data))))
#### pdata 
td = 65536; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_29/dibenzofuran/nmr/bmse000548/13C/pdata/1/1r", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
real = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_29/dibenzofuran/nmr/bmse000548/13C/pdata/1/1i", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
imag = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);


z = c(1:((length(real))))
count=1;


dibenzofuranP<-new("NmrData")
dibenzofuranP@Proc@data<-complex(real=real[length(real):1]/(max(real)-min(real)),imaginary=imag[length(real):1]/(max(imag)-min(imag)))
dibenzofuranP@Proc@timeDomain=FALSE
dibenzofuranP@Acqu@nbOfPoints=td
dibenzofuranP@Acqu@spectralWidth=241.074964854309;#ppm (SW)
dibenzofuranP@Acqu@transmitterFreq=125.69961514396;# MHz (SFO1)


plot.spectrum(dibenzofuranNorm,xlim=range(75,160))
lines.spectrum(dibenzofuranP)



######## tryptophan 13C ######
td = 65536; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_05/L_tryptophan/nmr/bmse000050/13C/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

tryptophan<-new("NmrData")
tryptophan@fid<-z
tryptophan@Acqu@nbOfPoints=td
tryptophan@Acqu@spectralWidth=236.774158656829;#ppm (SW)
tryptophan@Acqu@transmitterFreq=125.697436454797;# MHz (SFO1)
tryptophan@Acqu@groupDelay=67.9838256835938 # group delay (units?) from acqus file (GRPDLY)
tryptophan@Acqu@dspFirmware=20 # (DSPFVS)
tryptophan@Acqu@decim=672 # (DECIM)

print("raw data")
plot.spectrum(tryptophan)
print("group delay correction")
plot.spectrum(groupDelayCorr(tryptophan))
tryptophan@Proc@referencePoint=15.55
tryptophanFold<-foldSpectrum(fourierTransform(apodization(groupDelayCorr(tryptophan))),foldingPoint=43.27,inversion=FALSE)
plot.spectrum(tryptophanFold,xlim=range(-1,1))

### the phase correction parameters are very similar to the ones in proc
##$PHC0= -66.77459
##$PHC1= -304.6767
plot.spectrum(phaseCorr(tryptophanFold,zeroOrder=-89.77,pivot=0,firstOrder=-304.67),inverted=TRUE)
tryptophanNorm<-phaseCorr(tryptophanFold,zeroOrder=-86.77,pivot=0,firstOrder=-304.67)
tryptophanNorm@Proc@data=complex(real=Re(tryptophanNorm@Proc@data)/(max(Re(tryptophanNorm@Proc@data))-min(Re(tryptophanNorm@Proc@data))),imaginary=Im(tryptophanNorm@Proc@data)/(max(Im(tryptophanNorm@Proc@data))-min(Im(tryptophanNorm@Proc@data))))

#### pdata 
td = 32768; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_05/L_tryptophan/nmr/bmse000050/13C/pdata/1/1r", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
real = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read)
#real<-real[((c(1:td) %% 1) ==0) ]

to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_05/L_tryptophan/nmr/bmse000050/13C/pdata/1/1i", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
imag = readBin(to.read, integer(), n=td, size = 4, endian = "little");
#imag<-imag[((c(1:td) %% 1) == 0)]
close(to.read);

tryptophanP<-new("NmrData")
tryptophanP@Proc@data<-complex(real=real[length(real):1]/(max(real)-min(real)),imaginary=imag[length(real):1]/(max(imag)-min(imag)))
tryptophanP@Proc@timeDomain=FALSE
tryptophanP@Acqu@nbOfPoints=length(real)
tryptophanP@Acqu@transmitterFreq=125.68451047827;# MHz (SFO1)
sw_p=29761.9047619048 # Hz (sw)
#sw_h=spectralwidth*transmitterFreq;
tryptophanP@Acqu@spectralWidth=sw_p/tryptophanP@Acqu@transmitterFreq
tryptophanP@Proc@referencePoint=15.55

plot.spectrum(tryptophanNorm,inverted=TRUE)
lines.spectrum(tryptophanP)



######## aminobenzoic 13C ######
td = 65536; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_01/4_aminobenzoic_acid/nmr/bmse000066/13C/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "big");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

aminobenzoic<-new("NmrData")
aminobenzoic@fid<-z
aminobenzoic@Acqu@nbOfPoints=td
aminobenzoic@Acqu@spectralWidth=236.774158656829;#ppm (SW)
aminobenzoic@Acqu@transmitterFreq=100.62480252748;# MHz (SFO1)
#aminobenzoic@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
aminobenzoic@Acqu@dspFirmware=10 # (DSPFVS)
aminobenzoic@Acqu@decim=6 # (DECIM)

print("raw data")
plot.spectrum(aminobenzoic)
print("group delay correction")
plot.spectrum(groupDelayCorr(aminobenzoic))
print("apodization")
plot.spectrum(apodization(groupDelayCorr(aminobenzoic)))
print("ff transform")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(aminobenzoic))))
## note that the fid starts with zeros
plot.spectrum(groupDelayCorr(aminobenzoic),xlim=range(0,0.0013))
0.0012/getDwell(aminobenzoic)
aminobenzoic@Proc@leftShift=60
aminobenzoicProc<-fourierTransform(apodization(groupDelayCorr(zeroFill(aminobenzoic,td/2)),lb=3,method="GAU"))
plot.spectrum(phaseCorr(aminobenzoicProc,zeroOrder=90))
## the signal to noise is really bad to need to do 
##  apodization 
##  add zeros to the tail 
##  first order phase correction

## final touch a baseline correction
plot.spectrum(baselineCorr(phaseCorr(fourierTransform(apodization(groupDelayCorr(zeroFill(aminobenzoic,1e5)),lb=2)),zeroOrder=98,firstOrder=740,pivot=7.2)))

######## aminobenzoic DEPT 90 ######
td = 65536; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_01/4_aminobenzoic_acid/nmr/bmse000066/DEPT_135/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "big");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

aminobenzoicDEPT<-new("NmrData")
aminobenzoicDEPT@fid<-z
aminobenzoicDEPT@Acqu@nbOfPoints=td
aminobenzoicDEPT@Acqu@spectralWidth=170.175607854609;#ppm (SW)
aminobenzoicDEPT@Acqu@transmitterFreq=100.62480252748;# MHz (SFO1)
#aminobenzoicDEPT@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
aminobenzoicDEPT@Acqu@dspFirmware=10 # (DSPFVS)
aminobenzoicDEPT@Acqu@decim=8 # (DECIM)

print("raw data")
plot.spectrum(aminobenzoicDEPT)
print("group delay correction")
plot.spectrum(groupDelayCorr(aminobenzoicDEPT))
print("apodization")
plot.spectrum(apodization(groupDelayCorr(aminobenzoicDEPT)))
print("ff transform")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(aminobenzoicDEPT))))
## note that the fid starts with zeros
plot.spectrum(groupDelayCorr(aminobenzoicDEPT),xlim=range(0,0.0024))
0.00192/getDwell(aminobenzoicDEPT)
aminobenzoicDEPT@Proc@leftShift=70
aminobenzoicDEPTProc<-fourierTransform(apodization(groupDelayCorr(zeroFill(aminobenzoicDEPT,td/2)),lb=3,method="GAU"))
plot.spectrum(phaseCorr(aminobenzoicDEPTProc,zeroOrder=0))
## there seems to be some sort of aliasing in the spectra 
## to solve this one needs to slide the datapoints back to the other side of the spectra
## the quick and dirty way of doing this is 
index<-c(7901:length(aminobenzoicDEPTProc@Proc@data))
index[(length(index)+1):(length(index)+7900)]<-c(1:7900)
aminobenzoicDEPTProc@Proc@data<-aminobenzoicDEPTProc@Proc@data[index]
plot.spectrum(aminobenzoicDEPTProc,xlim=range(116,119))
plot.spectrum(aminobenzoicDEPTProc,xlim=range(135,113))
plot.spectrum(phaseCorr(aminobenzoicDEPTProc,zeroOrde=-30,pivot=118.86,firstOrder=-650),xlim=range(137,114))
plot.spectrum(phaseCorr(aminobenzoicDEPTProc,zeroOrde=-30,pivot=118.86,firstOrder=-650))

### using the folding option in plot.spectrum function
aminobenzoicDEPTProcFold<-fourierTransform(apodization(groupDelayCorr(zeroFill(aminobenzoicDEPT,td/2)),lb=3,method="GAU"))
plot.spectrum(phaseCorr(aminobenzoicDEPTProcFold,zeroOrder=0))
aminobenzoicDEPTProcFold@Proc@referencePoint=158.89-117.86
plot.spectrum(phaseCorr(aminobenzoicDEPTProcFold,zeroOrder=0),foldingPoint=-1)

### using the foldSpectrum method
aminobenzoicDEPTProcFold2<-fourierTransform(apodization(groupDelayCorr(zeroFill(aminobenzoicDEPT,td/2)),lb=3,method="GAU"))
plot.spectrum(phaseCorr(foldSpectrum(aminobenzoicDEPTProcFold2,foldingPoint=41.30),zeroOrder=0))
plot.spectrum(phaseCorr(foldSpectrum(aminobenzoicDEPTProcFold2,foldingPoint=41.35),zeroOrder=-32,pivot=117.56,firstOrder=1300),xlim=range(117,134))

plot.spectrum(phaseCorr(foldSpectrum(aminobenzoicDEPTProcFold2,foldingPoint=41.35),zeroOrder=-32,pivot=117.56,firstOrder=1300))


