library(nmRPro)

######## aminobenzoic 1H ######
td = 32768; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_01/4_aminobenzoic_acid/nmr/bmse000066/1H/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "big");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

aminobenzoic<-new("NmrData")
aminobenzoic@fid<-z
aminobenzoic@Acqu@nbOfPoints=td
aminobenzoic@Acqu@spectralWidth=12.0152693165838;#ppm (SW)
aminobenzoic@Acqu@transmitterFreq=400.131880611;# MHz (SFO1)
#aminobenzoic@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
aminobenzoic@Acqu@dspFirmware=12 # (DSPFVS)
aminobenzoic@Acqu@decim=32 # (DECIM)

print("raw data")
plot.spectrum(aminobenzoic)
print("group delay correction")
plot.spectrum(groupDelayCorr(aminobenzoic))
print("apodization")
plot.spectrum(apodization(groupDelayCorr(aminobenzoic)))
print("ff transform")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(aminobenzoic))))
## note that the fid starts with zeros
plot.spectrum(groupDelayCorr(aminobenzoic),xlim=range(0,0.008))
7.467e-3/getDwell(aminobenzoic)
aminobenzoic@Proc@leftShift=70
aminobenzoicProc<-fourierTransform(groupDelayCorr(aminobenzoic))
plot.spectrum(phaseCorr(aminobenzoicProc,zeroOrder=90),ylim=range(-1e5,(max(Re(aminobenzoicProc@Proc@data))/1e2)),xlim=range(6.90,10.5))
## the signal to noise is really bad to need to do 
##  apodization 
##  add zeros to the tail 
##  first order phase correction
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(zeroFill(aminobenzoic,1e5)),lb=2)),zeroOrder=98,firstOrder=740,pivot=7.2),ylim=range(-1e2,(max(Re(aminobenzoicProc@Proc@data))/1e1)),xlim=range(6.90,10.5))
## final touch a baseline correction ## there seems to be no big improvement in the baseline
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(zeroFill(aminobenzoic,1e5)),lb=2)),zeroOrder=98,firstOrder=740,pivot=7.2),ylim=range(-1e2,(max(Re(aminobenzoicProc@Proc@data))/1e2)))
lines.spectrum(baselineCorr(phaseCorr(fourierTransform(apodization(groupDelayCorr(zeroFill(aminobenzoic,1e5)),lb=2)),zeroOrder=98,firstOrder=740,pivot=7.2)))
#plot.spectrum(baselineCorr(phaseCorr(fourierTransform(apodization(groupDelayCorr(zeroFill(aminobenzoic,1e5)),lb=2)),zeroOrder=98,firstOrder=740,pivot=7.2)),ylim=range(-1e2,(max(Re(aminobenzoicProc@Proc@data))/1e1)),xlim=range(6.90,10.5))


######## chloroaniline 1H ######
td = 32768; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_01/5_acetylamido_2_chloroaniline/nmr/bmse000143/1H/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "big");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

chloroaniline<-new("NmrData")
chloroaniline@fid<-z
chloroaniline@Acqu@nbOfPoints=td
chloroaniline@Acqu@spectralWidth=12.0152693165838;#ppm (SW)
chloroaniline@Acqu@transmitterFreq=400.131880611;# MHz (SFO1)
chloroaniline@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
chloroaniline@Acqu@dspFirmware=12 # (DSPFVS)
chloroaniline@Acqu@decim=32 # (DECIM)

print("raw data")
plot.spectrum(chloroaniline)
print("group delay correction")
plot.spectrum(groupDelayCorr(chloroaniline))
print("apodization")
plot.spectrum(apodization(groupDelayCorr(chloroaniline)))
print("ff transform")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(chloroaniline))))
## note that the fid starts with zeros
plot.spectrum(groupDelayCorr(chloroaniline),xlim=range(0,0.008))
7.467e-3/getDwell(chloroaniline)
chloroaniline@Proc@leftShift=70
chloroanilineProc<-fourierTransform(apodization(groupDelayCorr(zeroFill(chloroaniline,2e3)),lb=1,method='EXP'))
## the signal to noise is really bad to need to do 
##  apodization 
##  add zeros to the tail 
##  first order phase correction
plot.spectrum(phaseCorr(chloroanilineProc,zeroOrder=-120,firstOrder=-350,pivot=0),ylim=range(-1e6,(max(Re(chloroanilineProc@Proc@data))/1e1)))
plot.spectrum(phaseCorr(chloroanilineProc,zeroOrder=-120,firstOrder=-350,pivot=0),ylim=range(-1e6,(max(Re(chloroanilineProc@Proc@data))/1e2)))
## final touch a baseline correction
plot.spectrum(baselineCorr(phaseCorr(chloroanilineProc,zeroOrder=-122,firstOrder=-350,pivot=2.3),method="TOPHAT"),ylim=range(-1e3,(max(Re(chloroanilineProc@Proc@data))/1e1)))
plot.spectrum(baselineCorr(phaseCorr(chloroanilineProc,zeroOrder=-122,firstOrder=-350,pivot=2.3),method="TOPHAT"),ylim=range(-1e4,(max(Re(chloroanilineProc@Proc@data))/3e1)),xlim=range(8,1.6))

######## 3_hydroxybutyrate 1H ######
td = 19478; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_01/3_hydroxybutyrate/nmr/bmse000161/1H/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

hydroxybutyrate<-new("NmrData")
hydroxybutyrate@fid<-z
hydroxybutyrate@Acqu@nbOfPoints=td
hydroxybutyrate@Acqu@spectralWidth=12.9911091032519;#ppm (SW)
hydroxybutyrate@Acqu@transmitterFreq=499.842349248;# MHz (SFO1)
hydroxybutyrate@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
hydroxybutyrate@Acqu@dspFirmware=20 # (DSPFVS)
hydroxybutyrate@Acqu@decim=3080 # (DECIM)

print("raw data")
plot.spectrum(hydroxybutyrate)
print("group delay correction")
plot.spectrum(groupDelayCorr(hydroxybutyrate))
print("apodization")
plot.spectrum(apodization(groupDelayCorr(hydroxybutyrate)))
print("ff transform")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(hydroxybutyrate))))
hydroxybutyrate@Proc@referencePoint=2.055
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(hydroxybutyrate))),zeroOrder=-13,pivot=0,firstOrder=-130),ylim=range(-1e7,1e7),xlim=range(-0.3,4.8))
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(hydroxybutyrate))),zeroOrder=-13,pivot=0,firstOrder=-130),ylim=range(-1e4,1e8),xlim=range(-0.3,4.8))

######## D_allose 1H ######
td = 19478; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_02/D_allose/nmr/bmse000008/1H/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

allose<-new("NmrData")
allose@fid<-z
allose@Acqu@nbOfPoints=td
allose@Acqu@spectralWidth=12.9911091032519;#ppm (SW)
allose@Acqu@transmitterFreq=499.842349248;# MHz (SFO1)
allose@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
allose@Acqu@dspFirmware=20 # (DSPFVS)
allose@Acqu@decim=3080 # (DECIM)

print("raw data")
plot.spectrum(allose)
print("group delay correction")
plot.spectrum(groupDelayCorr(allose))
print("apodization")
plot.spectrum(apodization(groupDelayCorr(allose)))
print("ff transform")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(allose))))
allose@Proc@referencePoint=2.069
# zero order phase correction
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(allose))),zeroOrder=-38),xlim=range(0.2,-0.2))
# first order correction
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(allose))),zeroOrder=-38,pivot=0,firstOrder=-135),xlim=range(-0.2,5.8))
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(allose))),zeroOrder=-38,pivot=0,firstOrder=-135),xlim=range(3.35,4.3),ylim=range(-1e2,7e7))

######## phenylethanol 1H ######
td = 32768; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_14/2_Amino_1_phenylethanol/nmr/bmse000307/1H/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "big");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

phenylethanol<-new("NmrData")
phenylethanol@fid<-z
phenylethanol@Acqu@nbOfPoints=td
phenylethanol@Acqu@spectralWidth=14.010019607144;#ppm (SW)
phenylethanol@Acqu@transmitterFreq=499.84234974784;# MHz (SFO1)
phenylethanol@Acqu@dspFirmware=12 # (DSPFVS)
phenylethanol@Acqu@decim=24 # (DECIM)

print("raw data")
plot.spectrum(phenylethanol)
print("group delay correction")
plot.spectrum(groupDelayCorr(phenylethanol))

print("apodization")
plot.spectrum(apodization(groupDelayCorr(phenylethanol)))
print("ff transform")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(phenylethanol))))
### get ride of the zeros in front of the fid
4.8e-3/getDwell(phenylethanol)
phenylethanol@Proc@leftShift=67
plot.spectrum(fourierTransform(apodization(groupDelayCorr(phenylethanol))))
phenylethanol@Proc@referencePoint=2.870
# zero order phase correction
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(phenylethanol))),zeroOrder=140),xlim=range(-0.2,0.2))
# first order correction
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(phenylethanol))),zeroOrder=140,pivot=0,firstOrder=1170))
# baseline correction 
plot.spectrum(baselineCorr(phaseCorr(fourierTransform(apodization(groupDelayCorr(phenylethanol))),zeroOrder=140,pivot=0,firstOrder=1170)))
# baseline correction with tophat
lines.spectrum(baselineCorr(phaseCorr(fourierTransform(apodization(groupDelayCorr(phenylethanol))),zeroOrder=140,pivot=0,firstOrder=1170)),method="TOPHAT")

######## 2-Ketobutyric acid 1H - HMDB00005- varian ######

td = 57600; # number of points in the FID
finfo=file.info("/Users/ldpf/Data/Databases/HMDB/NMR/HMDB00005/2-Ketobutyric acid_noesy.fid/fid")
to.read = file("/Users/ldpf/Data/Databases/HMDB/NMR/HMDB00005/2-Ketobutyric acid_noesy.fid/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
### read the binary data from the file
binaryData = readBin(to.read, "raw", n=finfo$size, size = 1, endian = "big");
close(to.read);

## get file header
# 9 integers encoded as 32 bits integer - 4 octets
fileHeader<-readBin(t(binaryData[1:(9*4)]),"integer", size = 4, n = 3 * 32,endian="big")
## get block header
blockHeader<-readBin(t(binaryData[(9*4+1):((9*4)+6*4)]),"integer", size = 4, n = 7 * 28,endian="big")
## get fid
fid<-readBin(t(binaryData[((9*4)+6*4+1):length(binaryData)]),"integer", size = 4, n = 57600,endian="big")

z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  # the sequence of real and imag datapoints seem to be different from bruker
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

Ketobutyric<-new("NmrData")
Ketobutyric@fid<-z
Ketobutyric@Acqu@nbOfPoints=td
sw_h=7200.07200072 # Hz (sw)
#sw_h=spectralwidth*transmitterFreq;
Ketobutyric@Acqu@transmitterFreq=599.4094446;# MHz (sfrq)
Ketobutyric@Acqu@spectralWidth=sw_h/Ketobutyric@Acqu@transmitterFreq;#ppm (SW)
#Ketobutyric@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
#Ketobutyric@Acqu@dspFirmware=12 # (DSPFVS)
#Ketobutyric@Acqu@decim=32 # (DECIM)

print("raw data")
plot.spectrum(Ketobutyric)
# bruker fast fourier transform
plot.spectrum(fourierTransform(apodization(Ketobutyric)))
# varian spectra need a different processing
plot.spectrum(phaseCorr(fourierTransform(apodization(Ketobutyric),isBruker=FALSE),zeroOrder=105),xlim=range(1.1,1.3))
Ketobutyric@Proc@referencePoint=1.22
plot.spectrum(phaseCorr(fourierTransform(apodization(Ketobutyric),isBruker=FALSE),zeroOrder=105))
plot.spectrum(phaseCorr(fourierTransform(apodization(Ketobutyric),isBruker=FALSE),zeroOrder=105,pivot=0,firstOrder=15),xlim=range(-0.2,5))
plot.spectrum(phaseCorr(fourierTransform(apodization(Ketobutyric),isBruker=FALSE),zeroOrder=105,pivot=0,firstOrder=15),xlim=range(-0.2,2.9))

######## 2-Methoxyestrone HMDB00010 1H ######
td = 57690; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/HMDB/NMR/HMDB00010/133/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

Methoxyestrone<-new("NmrData")
Methoxyestrone@fid<-z
Methoxyestrone@Acqu@nbOfPoints=td
Methoxyestrone@Acqu@spectralWidth=12.0125673420675;#ppm (SW)
Methoxyestrone@Acqu@transmitterFreq=600.3328228;# MHz (SFO1)
Methoxyestrone@Acqu@groupDelay=67.9858856201172 # group delay (units?) from acqus file (GRPDLY)
Methoxyestrone@Acqu@dspFirmware=20 # (DSPFVS)
#Methoxyestrone@Acqu@decim=2773.33333333333 # (DECIM)

print("raw data")
plot.spectrum(Methoxyestrone)
print("group delay correction")
plot.spectrum(groupDelayCorr(Methoxyestrone))
print("apodization")
plot.spectrum(apodization(groupDelayCorr(Methoxyestrone)))
print("ff transform")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(Methoxyestrone))))
Methoxyestrone@Proc@referencePoint=5.522
# folding in the right place
plot.spectrum(fourierTransform((groupDelayCorr(Methoxyestrone))),inverted=TRUE,foldingPoint=-1)
plot.spectrum(fourierTransform((groupDelayCorr(Methoxyestrone))),inverted=TRUE,foldingPoint=-1,xlim=range(-0.2,3.8))
### folding using the foldSpectrum method
MethoxyestroneProc<-fourierTransform(groupDelayCorr(Methoxyestrone))
MethoxyestroneProc@Proc@referencePoint=0.322 
plot.spectrum(foldSpectrum(MethoxyestroneProc,inversion=FALSE,foldingPoint=4.878),inverted=TRUE)
plot.spectrum(foldSpectrum(MethoxyestroneProc,inversion=FALSE,foldingPoint=4.878),inverted=TRUE,xlim=range(-0.1,0.1))
## do phase correction
plot.spectrum(foldSpectrum(MethoxyestroneProc,inversion=FALSE,foldingPoint=4.878),inverted=TRUE,xlim=range(-0.1,0.1))

plot.spectrum(phaseCorr(foldSpectrum(MethoxyestroneProc,inversion=FALSE,foldingPoint=4.878),zeroOrder=-4,pivot=0,firstOrder=-31),inverted=TRUE,ylim=range(-1e6,1e7))
plot.spectrum(phaseCorr(foldSpectrum(MethoxyestroneProc,inversion=FALSE,foldingPoint=4.878),zeroOrder=-4,pivot=0,firstOrder=-31),inverted=TRUE,ylim=range(-1e6,1e8))
plot.spectrum(phaseCorr(foldSpectrum(MethoxyestroneProc,inversion=FALSE,foldingPoint=4.878),zeroOrder=-4,pivot=0,firstOrder=-25),inverted=TRUE,ylim=range(-1e6,4e7),xlim=range(2.8,1.2))

########  Carnosine HMDB00033 1H - varian ######

td = 57600; # number of points in the FID (np)
finfo=file.info("/Users/ldpf/Data/Databases/HMDB/NMR/HMDB00033/Carnosine_noesy.fid/fid")
to.read = file("/Users/ldpf/Data/Databases/HMDB/NMR/HMDB00033/Carnosine_noesy.fid/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
### read the binary data from the file
binaryData = readBin(to.read, "raw", n=finfo$size, size = 1, endian = "big");
close(to.read);

## get file header
# 9 integers encoded as 32 bits integer - 4 octets
fileHeader<-readBin(t(binaryData[1:(9*4)]),"integer", size = 4, n = 3 * 32,endian="big")
## get block header
blockHeader<-readBin(t(binaryData[(9*4+1):((9*4)+6*4)]),"integer", size = 4, n = 7 * 28,endian="big")
## get fid
fid<-readBin(t(binaryData[((9*4)+6*4+1):length(binaryData)]),"integer", size = 4, n = td,endian="big")

z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  # the sequence of real and imag datapoints seem to be different from bruker
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

Carnosine<-new("NmrData")
Carnosine@fid<-z
Carnosine@Acqu@nbOfPoints=td
sw_h=7200.07200072 # Hz (sw)
#sw_h=spectralwidth*transmitterFreq;
Carnosine@Acqu@transmitterFreq=599.4094446;# MHz (sfrq)
Carnosine@Acqu@spectralWidth=sw_h/Carnosine@Acqu@transmitterFreq;#ppm (SW)
#Carnosine@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
#Carnosine@Acqu@dspFirmware=12 # (DSPFVS)
#Carnosine@Acqu@decim=32 # (DECIM)
print("raw data")
plot.spectrum(Carnosine)
# fast fourier transform
plot.spectrum(fourierTransform(apodization(Carnosine),isBruker=FALSE))
Carnosine@Proc@referencePoint=1.209
plot.spectrum(phaseCorr(fourierTransform(apodization(Carnosine),isBruker=FALSE),zeroOrder=105),xlim=range(-0.1,0.1))
plot.spectrum(phaseCorr(fourierTransform(apodization(Carnosine),isBruker=FALSE),zeroOrder=105,pivot=0,firstOrder=18),xlim=range(4,2),ylim=range(-1e3,6e6))
plot.spectrum(phaseCorr(fourierTransform(apodization(Carnosine),isBruker=FALSE),zeroOrder=105,pivot=0,firstOrder=18),xlim=range(8,-0.1),ylim=range(-1e3,6e6))


########  7-Dehydrocholesterol HMDB00032 1H - varian ######

td = 47976; # number of points in the FID (np)
finfo=file.info("/Users/ldpf/Data/Databases/HMDB/NMR/HMDB00032/050106_P00_07_IS_1DP_Noesy/fid")
to.read = file("/Users/ldpf/Data/Databases/HMDB/NMR/HMDB00032/050106_P00_07_IS_1DP_Noesy/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
### read the binary data from the file
binaryData = readBin(to.read, "raw", n=finfo$size, size = 1, endian = "big");
close(to.read);

## get file header
# 9 integers encoded as 32 bits integer - 4 octets
fileHeader<-readBin(t(binaryData[1:(9*4)]),"integer", size = 4, n = 3 * 32,endian="big")
## get block header
blockHeader<-readBin(t(binaryData[(9*4+1):((9*4)+6*4)]),"integer", size = 4, n = 7 * 28,endian="big")
## get fid
fid<-readBin(t(binaryData[((9*4)+6*4+1):length(binaryData)]),"integer", size = 4, n = td,endian="big")

z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  # the sequence of real and imag datapoints seem to be different from bruker
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

Dehydrocholesterol<-new("NmrData")
Dehydrocholesterol@fid<-z
Dehydrocholesterol@Acqu@nbOfPoints=td
sw_h=5997.00149925 # Hz (sw)
#sw_h=spectralwidth*transmitterFreq;
Dehydrocholesterol@Acqu@transmitterFreq=499.8271053;# MHz (sfrq)
Dehydrocholesterol@Acqu@spectralWidth=sw_h/Dehydrocholesterol@Acqu@transmitterFreq;#ppm (SW)
#Dehydrocholesterol@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
#Dehydrocholesterol@Acqu@dspFirmware=12 # (DSPFVS)
#Dehydrocholesterol@Acqu@decim=32 # (DECIM)
print("raw data")
plot.spectrum(Dehydrocholesterol)

plot.spectrum(fourierTransform(apodization(Dehydrocholesterol,lb=0.3,method="EXP"),isBruker=true))
# varian spectra need a different processing
plot.spectrum(phaseCorr(fourierTransform(apodization(Dehydrocholesterol),isBruker=FALSE),zeroOrder=105),xlim=range(1.1,1.3))
