library(nmRPro)
library(RGtk2)
library(playwith)
######## 3_hydroxybutyrate 1H ######
td = 19478; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_01/3_hydroxybutyrate/nmr/bmse000161/1H/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

hydroxybutyrate<-new("NmrData")
hydroxybutyrate@fid<-z
hydroxybutyrate@Acqu@nbOfPoints=td
hydroxybutyrate@Acqu@spectralWidth=12.9911091032519;#ppm (SW)
hydroxybutyrate@Acqu@transmitterFreq=499.842349248;# MHz (SFO1)
hydroxybutyrate@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
hydroxybutyrate@Acqu@dspFirmware=20 # (DSPFVS)
hydroxybutyrate@Acqu@decim=3080 # (DECIM)

print("raw data")
plot.spectrum(hydroxybutyrate)
print("group delay correction")
plot.spectrum(groupDelayCorr(hydroxybutyrate))
print("apodization")
plot.spectrum(apodization(groupDelayCorr(hydroxybutyrate)))
print("ff transform")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(hydroxybutyrate))))
hydroxybutyrate@Proc@referencePoint=2.055
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(hydroxybutyrate))),zeroOrder=-13,pivot=0,firstOrder=-130),ylim=range(-1e7,1e7),xlim=range(-0.3,4.8))
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(hydroxybutyrate))),zeroOrder=-13,pivot=0,firstOrder=-130),ylim=range(-1e4,1e8),xlim=range(-0.3,4.8))
hydroxybutyrateP<-phaseCorr(fourierTransform(apodization(groupDelayCorr(hydroxybutyrate))),zeroOrder=-10,pivot=0,firstOrder=-145)
hydroxybutyrateP@Proc@data<-complex(real=Re(hydroxybutyrateP@Proc@data)/(max(Re(hydroxybutyrateP@Proc@data))-min(Re(hydroxybutyrateP@Proc@data))),imaginary=Im(hydroxybutyrateP@Proc@data)/(max(Im(hydroxybutyrateP@Proc@data))-min(Im(hydroxybutyrateP@Proc@data))))

playwith(plot.spectrum(hydroxybutyrateP))

######## R_Lactate/nmr/bmse000269 1H ######
td = 32768; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_12/R_Lactate/nmr/bmse000269/1H/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "big");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

lactate<-new("NmrData")
lactate@fid<-z
lactate@Acqu@nbOfPoints=td
lactate@Acqu@spectralWidth=12.0152693165838;#ppm (SW)
lactate@Acqu@transmitterFreq=400.131880611;# MHz (SFO1)
#lactate@Acqu@groupDelay=67.985595703125 # group delay (units?) from acqus file (GRPDLY)
lactate@Acqu@dspFirmware=12 # (DSPFVS)
lactate@Acqu@decim=32 # (DECIM)

print("raw data")
plot.spectrum(lactate)
7.53e-3/getDwell(lactate)
lactate@Proc@leftShift=72
print("zero order phase correction")
lactate@Proc@referencePoint=2.305
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(lactate))),zeroOrder=78),xlim=range(0.1,-0.1),ylim=range(-1e3,2e4))
print("first order phase correction")
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(lactate))),zeroOrder=75,pivot=0,firstOrder=32),xlim=range(-0.1,5),ylim=range(-1e3,6e4))

lactateP<-phaseCorr(fourierTransform(apodization(groupDelayCorr(lactate))),zeroOrder=75,pivot=0,firstOrder=32)
lactateP@Proc@data<-complex(real=Re(lactateP@Proc@data)/(max(Re(lactateP@Proc@data))-min(Re(lactateP@Proc@data))),imaginary=Im(lactateP@Proc@data)/(max(Im(lactateP@Proc@data))-min(Im(lactateP@Proc@data))))


########  Hippuric_acid bmse000408 ######

td = 32768; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/bmrb/tar_20/Hippuric_acid/nmr/bmse000408/1H/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "big");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

Hippuric<-new("NmrData")
Hippuric@fid<-z
Hippuric@Acqu@nbOfPoints=td
Hippuric@Acqu@spectralWidth=14.010019607144;#ppm (SW)
Hippuric@Acqu@transmitterFreq=499.84234974784;# MHz (SFO1)
Hippuric@Acqu@dspFirmware=12 # (DSPFVS)
Hippuric@Acqu@decim=24 # (DECIM)

print("raw data")
plot.spectrum(Hippuric)
5e-3/getDwell(Hippuric)
Hippuric@Proc@leftShift=70
Hippuric@Proc@referencePoint=2.876
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(Hippuric))),zeroOrder=-28,pivot=0,firstOrder=60),inverted=TRUE,ylim=range(-1e3,4e6))
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(Hippuric))),zeroOrder=-28,pivot=0,firstOrder=65),inverted=TRUE,xlim=range(7.4,8.33),ylim=range(-1e3,4e6))

hippuricP<-phaseCorr(fourierTransform(apodization(groupDelayCorr(Hippuric))),zeroOrder=-28,pivot=0,firstOrder=65)

########  MTBLS1 - ADG19007u_437 - Control Group  - MetaboLights ######

td = 65536; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/MetaboLights/mtbls1/ADG19007u_437/10/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "big");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

mtbls1cg<-new("NmrData")
mtbls1cg@fid<-z
mtbls1cg@Acqu@nbOfPoints=td
mtbls1cg@Acqu@spectralWidth=20.0116255056133;#ppm (SW)
mtbls1cg@Acqu@transmitterFreq=699.87329054;# MHz (SFO1)
mtbls1cg@Acqu@dspFirmware=12 # (DSPFVS)
mtbls1cg@Acqu@decim=12 # (DECIM)

print("raw data")
plot.spectrum(mtbls1cg)
print("group delay correction")
plot.spectrum(groupDelayCorr(mtbls1cg))

print("apodization")
plot.spectrum(apodization(groupDelayCorr(mtbls1cg)))
print("ff transform")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(mtbls1cg))))
### get ride of the zeros in front of the fid
2.55e-3/getDwell(mtbls1cg)
mtbls1cg@Proc@leftShift=70
plot.spectrum(fourierTransform(apodization(groupDelayCorr(mtbls1cg))))
### phase correction 
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(mtbls1cg))),zeroOrder=0))
###
mtbls1cg@Proc@referencePoint=10.5425 ### it looks a bit high but it seems to be the case
### first order spectra correction
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(mtbls1cg))),zeroOrder=-2,pivot=0,firstOrder=-215),ylim=range(1e-4,1e8),xlim=range(-0.1,10))


mtbls1cgP<-phaseCorr(fourierTransform(apodization(groupDelayCorr(mtbls1cg))),zeroOrder=-2,pivot=0,firstOrder=-215)
mtbls1cgP@Proc@data<-complex(real=Re(mtbls1cgP@Proc@data)/(max(Re(mtbls1cgP@Proc@data))-min(Re(mtbls1cgP@Proc@data))),imaginary=Im(mtbls1cgP@Proc@data)/(max(Im(mtbls1cgP@Proc@data))-min(Im(mtbls1cgP@Proc@data))))

########  MTBLS1 - ADG10003u_007 - type 2 diabetes mellitus - MetaboLights ######

td = 65536; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/MetaboLights/mtbls1/ADG10003u_007/10/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "big");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

mtbls1t2dm<-new("NmrData")
mtbls1t2dm@fid<-z
mtbls1t2dm@Acqu@nbOfPoints=td
mtbls1t2dm@Acqu@spectralWidth=20.0116255056133;#ppm (SW)
mtbls1t2dm@Acqu@transmitterFreq=699.87329054;# MHz (SFO1)
mtbls1t2dm@Acqu@dspFirmware=12 # (DSPFVS)
mtbls1t2dm@Acqu@decim=12 # (DECIM)

print("raw data")
plot.spectrum(mtbls1t2dm)
print("group delay correction")
plot.spectrum(groupDelayCorr(mtbls1t2dm))

print("apodization")
plot.spectrum(apodization(groupDelayCorr(mtbls1t2dm)))
print("ff transform")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(mtbls1t2dm))))
### get ride of the zeros in front of the fid
2.55e-3/getDwell(mtbls1t2dm)
mtbls1t2dm@Proc@leftShift=70
plot.spectrum(fourierTransform(apodization(groupDelayCorr(mtbls1t2dm))))
### phase correction 
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(mtbls1t2dm))),zeroOrder=-97))
###
mtbls1t2dm@Proc@referencePoint=10.546 ### it looks a bit high but it seems to be the case
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(mtbls1t2dm))),zeroOrder=-97),xlim=range(-1,10))
### first order spectra correction
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(mtbls1t2dm))),zeroOrder=-97,pivot=0,firstOrder=-190),xlim=range(-1,10))

plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(mtbls1t2dm))),zeroOrder=-97,pivot=0,firstOrder=-190),xlim=range(6.6,9),ylim=range(-1e3,6e6))
mtbls1t2dmP<-phaseCorr(fourierTransform(apodization(groupDelayCorr(mtbls1t2dm))),zeroOrder=-97,pivot=0,firstOrder=-190)
mtbls1t2dmP@Proc@data<-complex(real=Re(mtbls1t2dmP@Proc@data)/(max(Re(mtbls1t2dmP@Proc@data))-min(Re(mtbls1t2dmP@Proc@data))),imaginary=Im(mtbls1t2dmP@Proc@data)/(max(Im(mtbls1t2dmP@Proc@data))-min(Im(mtbls1t2dmP@Proc@data))))

#### compare control group with t2dm

plot.spectrum(mtbls1t2dmP,xlim=range(-1,10),ylim=range(-0.02,0.2))
lines.spectrum(mtbls1cgP)


#### compare with hippuric acid

plot.spectrum(mtbls1t2dmP,xlim=range(7,8),ylim=range(-1e3,6e6))
lines.spectrum(hippuricP,inverted=TRUE,ylim=range(-1e3,4e6))


#### compare with lactate and hydroxybutyrate (annotation of figure 3 in Salek et al. 2006)
mtbls1cgP2<-mtbls1cgP
mtbls1cgP2@Proc@data<-complex(real=Re(mtbls1cgP2@Proc@data)*3,imaginary=Im(mtbls1cgP2@Proc@data))
lactateP2<-lactateP
lactateP2@Proc@referencePoint=lactateP@Proc@referencePoint-0.04
hydroxybutyrateP2<-hydroxybutyrateP
hydroxybutyrateP2@Proc@data<-complex(real=Re(hydroxybutyrateP@Proc@data)/5+0.03,imaginary=Im(hydroxybutyrateP@Proc@data))
hydroxybutyrateP2@Proc@referencePoint=hydroxybutyrateP@Proc@referencePoint+0.1

plot.spectrum(mtbls1cgP2,xlim=range(-0.1,4.5),ylim=range(-0.01,0.2))
lines.spectrum(lactateP2)
lines.spectrum(hydroxybutyrateP2,col="blue")



#### play a small trick to slide the reference
hippuricP2<-phaseCorr(fourierTransform(apodization(groupDelayCorr(Hippuric))),zeroOrder=-28,pivot=0,firstOrder=65)
hippuricP2@Proc@referencePoint=2.845
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(mtbls1t2dm))),zeroOrder=-97,pivot=0,firstOrder=-190),xlim=range(7,8),ylim=range(-1e3,6e6))
hippuricP2@Proc@data<-hippuricP@Proc@data-2e6
lines.spectrum(hippuricP2,inverted=TRUE,ylim=range(-1e3,4e6))





#### pdata  Processed data #####
td = 65536; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/MetaboLights/mtbls1/ADG10003u_007/10/pdata/1/1r", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fidRe = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

to.read = file("/Users/ldpf/Data/Databases/MetaboLights/mtbls1/ADG10003u_007/10/pdata/1/1i", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fidIm = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

z<-complex(real=fidRe[length(fidRe):1],imaginary=fidIm[length(fidRe):1])

mtbls1t2dmP<-new("NmrData")
mtbls1t2dmP@Proc@data<-z
mtbls1t2dmP@Proc@timeDomain=FALSE
mtbls1t2dmP@Acqu@nbOfPoints=td
mtbls1t2dmP@Acqu@spectralWidth=20.0116255056133;#ppm (SW)
mtbls1t2dmP@Acqu@transmitterFreq=699.87329054;# MHz (SFO1)
mtbls1t2dmP@Acqu@dspFirmware=12 # (DSPFVS)
mtbls1t2dmP@Acqu@decim=12 # (DECIM)

print("processed data - original")
plot.spectrum(mtbls1t2dmP)
mtbls1t2dmP@Proc@referencePoint=5.239 ### it looks a bit high but it seems to be the case
plot.spectrum(mtbls1t2dmP)

## compare spectra
nmrprocData<-phaseCorr(fourierTransform(apodization(groupDelayCorr(mtbls1t2dm))),zeroOrder=-97,pivot=0,firstOrder=-190)
nmrprocData@Proc@data<-complex(real=(Re(nmrprocData@Proc@data)/(max(Re(nmrprocData@Proc@data))-min(Re(nmrprocData@Proc@data)))),imaginary=(Im(nmrprocData@Proc@data)/(max(Im(nmrprocData@Proc@data))-min(Im(nmrprocData@Proc@data)))))
mtbls1t2dmP@Proc@data<-complex(real=(Re(mtbls1t2dmP@Proc@data)/(max(Re(mtbls1t2dmP@Proc@data))-min(Re(mtbls1t2dmP@Proc@data)))),imaginary=(Im(mtbls1t2dmP@Proc@data)/(max(Im(mtbls1t2dmP@Proc@data))-min(Im(mtbls1t2dmP@Proc@data)))))

plot.spectrum(nmrprocData,xlim=range(6.6,9),ylim=range(-0.0001,0.01))
lines.spectrum(mtbls1t2dmP)

### apply some baseline correction
plot.spectrum(baselineCorr(nmrprocData),xlim=range(6.6,9),ylim=range(-0.0001,0.01))
lines.spectrum(mtbls1t2dmP)




########  MTBLS24 - AKI_8_24_01_110722 MetaboLights ######

td = 65536; # number of points in the FID
to.read = file("/Users/ldpf/Data/Databases/MetaboLights/mtbls24/MTBLS24/AKI_8_24_01_110722/10/fid", "rb");
#BYTORDA= 0-> little; 1-> big
#DTYPA= 0 -> size=4 ; 1 -> size=8
fid = readBin(to.read, integer(), n=td, size = 4, endian = "little");
close(to.read);

fidRe = c(1:((length(fid))/2))
fidIm = c(1:((length(fid))/2))
z = c(1:((length(fid))/2))
count=1;

for (i in seq(from=1,to=length(fid), by=2)){
  fidRe[count]=fid[i]; # real channel values are even numbers (but starting from 0... so odd numbers in R)
  fidIm[count]=fid[i+1]; # immaginary channel values are odd numbers (even numbers in R)
  z[count]<-complex(real=fid[i],imaginary=fid[i+1]);
  count=count+1;
}

mtbls24<-new("NmrData")
mtbls24@fid<-z
mtbls24@Acqu@nbOfPoints=td
mtbls24@Acqu@spectralWidth=20.5505510241777;#ppm (SW)
mtbls24@Acqu@transmitterFreq=600.2528254;# MHz (SFO1)
mtbls24@Acqu@dspFirmware=21 # (DSPFVS)
mtbls24@Acqu@decim=1621.33333333333 # (DECIM)
mtbls24@Acqu@groupDelay=76 # group delay (units?) from acqus file (GRPDLY)

print("raw data")
plot.spectrum(mtbls24)
print("group delay correction")
plot.spectrum(fourierTransform(apodization(groupDelayCorr(mtbls24))),xlim=range(12.38,12.45))
mtbls24@Proc@referencePoint=12.405
plot.spectrum(phaseCorr(fourierTransform(apodization(groupDelayCorr(mtbls24))),zeroOrder=-20,pivot=0,firstOrder=-100),xlim=range(-1,10))



