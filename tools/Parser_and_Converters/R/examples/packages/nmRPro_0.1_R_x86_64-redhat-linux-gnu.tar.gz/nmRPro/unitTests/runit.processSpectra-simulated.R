### --- Test setup ---

if(FALSE) {
  ## Not really needed, but can be handy when writing tests
  library("RUnit")
  library("nmRPro")
}

######## putrescine case ######
CheShiftA = 1.761 # ppm
CheShiftB = 3.044 # ppm
#CheShiftB = 5 # ppm
RessFreq=500      # MHz
B0=11.75          # T
vRef=20            # Hz (this is just arbitrary)
vA=CheShiftA*RessFreq+vRef # Hz
vB=CheShiftB*RessFreq+vRef # Hz
#vB=90000

# we want the spectral window to be 2000 for the protons from putrescine
N=2^15;       # the sample size also has to increase :S
sw=2000;      # Hz
dw=1/(2*sw);    # s
T=1;
phase=0.5;
wref=2*pi*vRef; # rad-1 (??)
wa=2*pi*(vA);   # rad-1 (??)
wb=2*pi*(vB);   # rad-1 (??)
fid<-c(1:N);
fidImag<-c(1:N);
## Simultaneous and DISP FIDs
for (i in 0:(N-1)){
  # real channel
  fid[i+1]=cos(i*dw*wa+phase)*exp(-i*dw/T)+cos(i*dw*wb+phase)*exp(-i*dw/T)+cos(i*dw*wref+phase)*exp(-i*dw/T);
  # imaginary channel
  fidImag[i+1]= sin(i*dw*wa+phase)*exp(-i*dw/T) + sin(i*dw*wb+phase)*exp(-i*dw/T)+ sin(i*dw*wref+phase)*exp(-i*dw/T);
}
# calculate the frequency axis
freq<-c(0:(N-1));
freq<-apply(t(freq),1,function(x) x/(N*dw));
# calculate chemical shift axis 
CheShift<-c(0:(N-1));
CheShift<-apply(t(freq),1,function(x) (x-vRef)/RessFreq); # ppm

nmrData<-new("NmrData")
nmrData@fid<-complex(real=fid,imaginary=fidImag);
nmrData@Acqu@nbOfPoints=N
nmrData@Acqu@spectralWidth=sw/RessFreq;#ppm (SW)
nmrData@Acqu@transmitterFreq=RessFreq;# MHz (SF1)
# NO group delay data

#freqOfZero=499.84# MHz (SF)
dw=1/(2*nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq);
hzperpt=nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq/N;
ppmperpt=nmrData@Acqu@spectralWidth/N;
sw_h=nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq;
#offset=(nmrData@Acqu@transmitterFreq- freqOfZero) * 1.0e06 + (nmrData@Acqu@spectralWidth*nmrData@Acqu@transmitterFreq ) / 2.0;
##############

### --- Test functions ---

test.groupDelayCorrection <- function()
{
  # scenario where without zero filling
  mnrDataNew<-groupDelayCorr(nmrData)
  plot(Re(mnrDataNew@Proc@data),type='l')
  
  # scenario where with zero filling
  zeroFilledData<-zeroFill(nmrData,1000);
  nmrDataNew<-groupDelayCorr(zeroFilledData)
  
  plot(Re(mnrDataNew@Proc@data),type='l')
  
}

# it is working
# TODO write a proper test 
test.apodization <- function(){
  # exponential with no previous preprocessing
  nmrDataApo<-apodization(nmrData,lb=2,method="EXP")
  
  # exponential with previous preprocessing
  nmrDataApo<-apodization(zeroFill(nmrData,1000),lb=2,method="EXP")
  
  return (nmrDataApo)
}

# TODO write a proper test 
test.fourierTransform <- function(){
  # exponential with no previous preprocessing
  spectra<-fourierTransform(nmrData)
  
  return (spectra)
}
