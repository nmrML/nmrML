### --- Test setup ---

if(FALSE) {
  ## Not really needed, but can be handy when writing tests
  library("RUnit")
  library("nmrproc")
}

nmrData<-new("NmrData")
nmrData@fid<-complex(real=c(1:10),imaginary=(1:10))

### --- Test functions ---

test.zeroFill <- function()
{
  zeros = array(data=0,dim=10);
  fidLength=length(nmrData@fid);
  data<-zeroFill(nmrData,10)@Proc@data;
  # check first the sizes
  checkEquals(current=length(data),target=(fidLength+10),
              msg=' number of points added to the fid are incorrect')
  
  # check the actual data
  checkEquals(current=data[(fidLength+1):(fidLength+10)],
              target=complex(real=zeros,imaginary=zeros),
              msg=' zero filling method is broken')
}

test.zeroFill()