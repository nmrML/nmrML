/*
# Nom du fichier: spectrum.js
# Auteur(s): D.Jacob
# Copyright: (c) CBiB - 2011
*/
 
var ObjImage = function () {
   // GUI elements
   this.iframe    = '';
   this.div       = 'DSPEC';
   this.img       = '#spec';
   this.msg       = '#right';
   this.waitdiv   = '#waitdiv';
   this.cursor    = '#verticale';
   this.container = '#MAINSPEC';
   this.unit      = 'ppm';
   
   // AJAX parameters
   this.AJ_PROG   = '';
   this.params    = '';
   this.callback  = function(){};

   // IMAGE size & margins (pixels)
   this.iwidth  = 800;
   this.iheight = 256;
   this.x1     = 70;
   this.x2     = 793;
   this.y1     = 12;
   this.y2     = 232;

   // Maximal boundaries of the X coordinate (in unit)
   this.SpecValMin=0;
   this.SpecValMax=0;

   // Current boundaries of the X coordinate (in unit)
   this.Xmin   = 0;
   this.Xmax   = 0;

   // internal variables
   this.val    = 0;
   this.val2   = 0;
   this.ox     = 0;
   this.oy     = 0;
   this.xpos   = 0;
   this.ypos   = 0;
   this.xneg   = 0;
   this.xval   = 0;
   this.mDwn   = 0;
   this.keycode= 0;
   this.flg    = 0;
   this.first  = 1;  // first call

   this.init = function (iwidth, iheight, x1,x2,y1,y2,Xmin,Xmax,SpecValMin,SpecValMax,xneg) {
       this.x1 = x1; this.x2 = x2; this.y1 = y1; this.y2 = y2;
       this.Xmin = Xmin; this.Xmax = Xmax;
       this.iwidth = iwidth; this.iheight = iheight;
       this.SpecValMin=SpecValMin; this.SpecValMax=SpecValMax;
       this.xneg = xneg;
   }

   this.coords = function (e) { // capturer position de la souris
       var flg = 0;
       this.ox   = $(this.img).offset().left;
       this.oy   = $(this.img).position().top;
       var d = document.documentElement, b = document.body;
       this.xpos = isIE ? event.clientX + d.scrollLeft + b.scrollLeft : e.pageX;
       this.ypos = isIE ? event.clientY + d.scrollTop + b.scrollTop : e.pageY;
       if (isIE) { this.ox += 2; this.oy += 2;}
       this.xpos -= this.ox; this.ypos -= this.oy;
       if (isIE) { this.xpos -= 2; this.ypos -=2; }
       if (this.ypos<=this.iheight && this.ypos>=0 )
           flg =1 ;
       this.flg = flg ;
       return flg;
   }

   this.getVal = function (x) {
       var val;
       var xmax = this.x2 - this.x1 - 1;
       if (x>=0 && x<=xmax) {
          val = this.xneg ? Math.round(1000*(this.Xmax + (x/xmax)*(this.Xmin-this.Xmax)) )/1000 : 
                            Math.round(1000*((x/xmax)*(this.Xmax-this.Xmin) + this.Xmin) )/1000;
       }
       return val;
   }

   this.cursorDraw = function (x) {
     $(this.cursor).css('position','absolute');
     if (this.mDwn==0) {
         $(this.cursor).css({ 'borderRight' : '0px #00ff00', 'width' : 0 +'px', 'height' : this.y2 - this.y1 +'px', 
                              'top' : this.oy + this.y1 + 'px', 'left' : x + 'px'});
         if (isIE) $(this.cursor).css('filter', 'alpha(opacity=100)'); else $(this.cursor).css('opacity', 1.0);
         $(this.cursor).css('z-index', 3);
     }
     else {
         $(this.cursor).css({ 'borderRight' : 'dotted 1px #ff0000', 'width' : x - this.xval +'px', 'height' : this.y2 - this.y1 +'px', 
                              'top' : this.oy + this.y1 + 'px','left' : this.xval + 'px'});
         if (isIE) $(this.cursor).css('filter', 'alpha(opacity=20)'); else $(this.cursor).css('opacity', 0.2);
     }
     $(this.cursor).css('display','inline');
   }

   this.cursorMove = function () {
     var x = this.xpos - this.x1;
     if (this.flg) {
        var xmax = this.x2 - this.x1 - 1;
        if (x>=0 && x<=xmax) {
            this.cursorDraw(this.xpos + this.ox)
            var val = this.getVal(x);
            if (this.mDwn)
                  this.xneg ? $(this.msg).text(this.unit+' : max='+sprintf("%06.3f",this.val)+' - min='+sprintf("%06.3f",val)) :
                              $(this.msg).text(this.unit+' : min='+sprintf("%06.3f",this.val)+' - max='+sprintf("%06.3f",val));

            else
                  $(this.msg).text(this.unit+' = '+sprintf("%06.3f",val));
        }
     }
   }

   this.captureWin = function () {
     var x = this.xpos - this.x1;
     if (this.flg) {
        var xmax = this.x2 - this.x1 - 1;
        this.val  = this.getVal(x);
        this.xval = this.xpos + this.ox;
        this.mDwn = 1;
     }
   }

   this.getNewIMG = function () {
     var x = this.xpos - this.x1;
     var xmax = this.x2 - this.x1 - 1;
     this.mDwn = 0;
     if (this.flg && x>=0 && x<=xmax) {
        this.val2  = this.getVal(x);
        var xval2 = this.xpos + this.ox;
        if (this.keycode==0) {
            if (this.xval < xval2) {
                this.xneg ? this.AJ_XMS('val1='+this.val2+'&val2='+this.val) :
                            this.AJ_XMS('val1='+this.val+'&val2='+this.val2);
            }
        }
     }
   }

   this.show_waitdiv = function () {
       $(this.waitdiv).css({'position':'absolute','width': '200px', 'height': '50px','overflow': 0, 'z-index': 10, 'background-color': '#FFFFFF',
                            'top' : this.oy + 50 +'px', 'left' : this.ox + 250 +'px', 'display' : 'inline'});
       $(this.container).unbind();
   }
   this.hide_waitdiv = function () {
       $(this.waitdiv).css('display','none');
       $(this.cursor).css('display','none');
       $(this.container).mousemove($.proxy(this.e_cursorMove,this));
       $(this.container).mousedown($.proxy(this.e_captureWin,this));
   }

   this.AJ_XMS = function (params) {
     var my_params = this.params;
     if (params) my_params += '&'+params;
     this.show_waitdiv();
     var self=this;
     $.ajax({
          url:self.AJ_PROG+my_params,
          global:true
     }).done(function ( response ) {
          setInnerHTML(document.getElementById(self.div),response);
          self.hide_waitdiv();
          setTimeout(self.resizeIframe,500);
          self.callback();
          self.first=0;
     });
   }

   this.zoom = function (zoomtype) {
      var delta = Math.abs(this.Xmax - this.Xmin)/2.5;
      var zmin  = Math.max(Math.min(Math.min(this.Xmin,this.Xmax) - zoomtype*delta, this.SpecValMax),this.SpecValMin);
      var zmax  = Math.max(Math.min(Math.max(this.Xmin,this.Xmax) + zoomtype*delta, this.SpecValMax),this.SpecValMin);
      this.AJ_XMS('val1='+Math.min(zmin,zmax)+'&val2='+Math.max(zmin,zmax));
   }

   this.view = function () {
       this.AJ_XMS('val1='+this.Xmin+'&val2='+this.Xmax);
       this.mDwn=0;
       $( this.container ).unbind('mouseup', this.e_cursorMove);
       $( this.container ).mousedown($.proxy(this.e_captureWin,this));
   }

   this.resizeIframe = function (e) {
      var self=this;
      $("iframe", window.parent.document).each (function() {
          if ( $( this ).attr('id').match(/ifspec_.+/)) {
               $( this ).css('height',$( this ).get(0).contentWindow.document.body.offsetHeight + 'px');
          }
      });
   }

   this.e_cursorMove = function (e) {
      if (!e) e = window.event;
      if (this.coords(e))  { this.cursorMove(); }
      else  window.focus();
   }

   this.e_captureWin = function (e) {
      if (!e) e = window.event;
      if (this.coords(e)) this.captureWin();
      $(this.container).unbind('mousedown');
      $(this.container).mouseup($.proxy(this.e_getNewIMG,this));
   }

   this.e_getNewIMG = function (e) {
      if (!e) e = window.event;
      if (this.coords(e)) this.getNewIMG();
      $(this.container).unbind('mouseup');
      $(this.container).mousedown($.proxy(this.e_captureWin,this));
   }

}
