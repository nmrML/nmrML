// To create a plugin, call the $.widget method
// 1st param: plugin name = namespace.name (ui is the jQuery's namespace)
// 2nd param: JSON object

$.widget("ui.nmrview", {

    // default options
    options: {
        url: '/SPECNMR/view',
        dataset: 'Simul',
        colorby: 1,
        width: 'auto'
    },

    // Internal variables
    iFrame_id: null,
    iFrame_name: null,

    // the _create function serves to build the object jQuery 'this.element'
    _create: function() {
       var url = this._geturl({});
       this.iFrame_id='ifspec_'+this.element.attr("id");
       this.iFrame_name='f'+this.element.attr("id")+'_name';
       this.element.addClass('ui-widget ui-widget-content ui-corner-all');
       this._myload(url);
       // Window Resize Event
       var self=this;
       if (self.options.width == "auto") {
           $(window).resize(function() {
              if(this.resizeTO) clearTimeout(this.resizeTO);
              this.resizeTO = setTimeout(function() {
                   $(this).trigger('resizeEnd');
               }, 500);
           });
           $(window).bind('resizeEnd', function() {
               var img_width = self.element.width()-80;
               if (self.options.dataset) self.refresh('IMGSIZE='+img_width);
           });
       }
    },

    _geturl: function (options) {
       if (options.url)     { this.options.url =  options.url; }
       if (options.dataset) { this.options.dataset = options.dataset; }
       if (options.colorby) { this.options.colorby = options.colorby; }
       var img_width = (this.options.width == "auto") ? this.element.width()-80 : this.options.width;
       return this.options.url + '/' + this.options.dataset + '?color_id=' + this.options.colorby + '&IMGSIZE=' + img_width;
    },

    _myload: function (url) {
       var frm_width = (this.options.width == "auto") ? this.element.width() : this.options.width+80;
       this.element.text('');
       var myiframe='<iframe id="' + this.iFrame_id + '" name="' + this.iFrame_name + '" src="' + url + '" ' +
                     'style="width:2000px;height:100%; min-height: 325px; overflow:visible"; scrolling="no" frameborder="0"></iframe>';
       this.element.append(myiframe);
    },

    load: function(options) {
       var url = this._geturl(options);
       this._myload(url);
    },

    // hide() Method :
    hide: function() {
       $('#'+this.iFrame_id).hide();
    },

    // show() Method :
    show: function() {
       $('#'+this.iFrame_id).show();
    },

    // clear() Method :
    clear: function() {
       this.element.text('');
    },

    // resize() Method : Resize Frame
    resize: function() {
       $('#'+this.iFrame_id).get(0).style.height = $('#'+this.iFrame_id).get(0).contentWindow.document.body.offsetHeight + 'px';
       $('#'+this.iFrame_id).get(0).style.width  = $('#'+this.iFrame_id).get(0).contentWindow.document.body.offsetWidth + 'px';
    },

    // refresh() Method :
    refresh: function(params) {
       this.resize;
       $('#'+this.iFrame_id).get(0).contentWindow.spectrum_view(params);
    },

    // zoom() Method :
    zoom: function(val) {
       $('#'+this.iFrame_id).get(0).contentWindow.Spectrum.zoom(val);
    },

    dataset: function(val) {
        if (val && val.length) this.options.dataset = val;
        else                   return this.options.dataset;
    },

    width: function(val) {
        if (val && val.length) this.options.width = val;
        else                   return this.options.width;
    }
    
});
