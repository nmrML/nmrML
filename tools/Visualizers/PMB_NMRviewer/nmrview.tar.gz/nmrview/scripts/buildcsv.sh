#!/bin/bash
SH=$(which sh)
MYDIR=$(dirname $0) && [ ! $(echo "$0" | grep '^\/') ] && MYDIR=$(pwd)/$MYDIR
PWD=$(pwd)

DIR=$MYDIR
DEBUG=0

INVEST=i_Investigation.txt
OUTPUT=samples.csv

# Get Cmd line arguments depending on options
while getopts d:o:v opt
do
       case $opt in
       d) DIR=$OPTARG ;;
       o) OUTPUT=$OPTARG ;;
       v) DEBUG=1 ;;
       esac
done

TMP=$DIR

# Investigation File
[ $DEBUG -eq 1 ] && echo -n "$INVEST ... "
if [ -f "$DIR/$INVEST" ]; then [ $DEBUG -eq 1 ] && echo "OK"; else [ $DEBUG -eq 1 ] && echo "BAD"; exit 1; fi

# Study File
STUDYFILE=$(grep '^Study File Name' $DIR/$INVEST | cut -f2 | sed -e "s/\"//g")
[ $DEBUG -eq 1 ] && echo -n "$STUDYFILE ... "
if [ -f "$DIR/$STUDYFILE" ]; then [ $DEBUG -eq 1 ] && echo "OK"; else [ $DEBUG -eq 1 ] && echo "BAD"; exit 1; fi

# Study Assay File Name
ASSAYFILE=$(grep '^Study Assay File Name' $DIR/$INVEST | cut -f2 | sed -e "s/\"//g")
[ $DEBUG -eq 1 ] && echo -n "$ASSAYFILE ... "
if [ -f "$DIR/$ASSAYFILE" ]; then [ $DEBUG -eq 1 ] && echo "OK"; else [ $DEBUG -eq 1 ] && echo "BAD"; exit 1; fi

# Extract Assay Names from Study Assay File
COLR=$(head -1 "$DIR/$ASSAYFILE" | tr '\t' '\n' | grep -n '^"NMR Assay Name"' | cut -d':' -f1)
COLS=$(head -1 "$DIR/$ASSAYFILE" | tr '\t' '\n' | grep -n '^"Sample Name"' | cut -d':' -f1)
[ $DEBUG -eq 1 ] && echo -n "Extract columns from Study Assay File : $COLS,$COLR ..."
cat "$DIR/$ASSAYFILE" | cut -f$COLS,$COLR | sed -e "s/\t/;/g" -e "s/\"//g" | grep -v "Sample Name" | sort -t';' > $TMP/assay.tmp
RET=$?
if [ $RET -eq 0 ]; then [ $DEBUG -eq 1 ] && echo "OK"; else [ $DEBUG -eq 1 ] && echo "BAD"; exit 1; fi

# Factors
FACLST=$(grep '^Study Factor Name' $DIR/$INVEST)
NBCOL=$(echo "$FACLST" | tr '\t' '\n' | wc -l)
NBFAC=$(expr $NBCOL - 1)
FACLST=$(grep '^Study Factor Name' $DIR/$INVEST | cut -f2-$NBCOL | sed -e "s/\t/;/g" -e "s/\"//g")

# Factor columns within Study File
COLS=$(head -1 "$DIR/$STUDYFILE" | tr '\t' '\n' | grep -n "Sample Name" | cut -d':' -f1)
i=1
while [ $i -le $NBFAC ]; do
    FACLABEL=$(echo "$FACLST" | cut -d';' -f$i)
    INFO=$(head -1 "$DIR/$STUDYFILE" | tr '\t' '\n' | grep -n "Factor Value\[$FACLABEL\]")
    if [ ! -z "$INFO" ]; then
       COLS="$COLS,"$(echo "$INFO" | cut -d':' -f1)
    fi
    i=$(expr $i + 1)
done

# Factor labels within Study File
i=1
FACLABELS=$(
   while [ $i -le $NBFAC ]; do
       FACLABEL=$(echo "$FACLST" | cut -d';' -f$i)
       INFO=$(head -1 "$DIR/$STUDYFILE" | tr '\t' '\n' | grep -n "Factor Value\[$FACLABEL\]")
       [ ! -z "$INFO" ] && echo "$INFO"
       i=$(expr $i + 1)
   done | sort | cut -d':' -f2 | sed -e "s/Factor Value/;/" -e "s/\"//g" -e "s/\[//g" -e "s/\]//g" | tr -d '\n'
)
[ $DEBUG -eq 1 ] && echo "Factors: $FACLABELS"

# Extract Factor columns from Study File
[ $DEBUG -eq 1 ] && echo -n "Extract columns from Study File : $COLS ... "
cat "$DIR/$STUDYFILE" | cut -f$COLS | sed -e "s/\t/;/g" -e "s/\"//g" | grep -v "Factor Value" | sort -t';' > $TMP/study.tmp
RET=$?
if [ $RET -eq 0 ]; then [ $DEBUG -eq 1 ] && echo "OK"; else [ $DEBUG -eq 1 ] && echo "BAD"; exit 1; fi

# Check if we have the same number of samples within two files
N1=$(wc -l $TMP/study.tmp | cut -d' ' -f1)
N2=$(wc -l $TMP/assay.tmp | cut -d' ' -f1)
[ "$N1" != "$N2" ] && echo "ERROR: inconsistent sample numbers" && exit 1

# Merge two files
echo ";$FACLABELS" > $DIR/$OUTPUT
[ $DEBUG -eq 1 ] && echo -n "Merging ..."
paste -d';' $TMP/assay.tmp $TMP/study.tmp | sed -e "s/^[^;]\+;//" >> $DIR/$OUTPUT
RET=$?
rm -f $TMP/assay.tmp
rm -f $TMP/study.tmp

if [ $RET -eq 0 ]; then [ $DEBUG -eq 1 ] && echo "OK"; else [ $DEBUG -eq 1 ] && echo "BAD"; exit 1; fi

