#!/bin/bash
SH=`which sh`
MYDIR=`dirname $0` && [ ! `echo "$0" | grep '^\/'` ] && MYDIR=`pwd`/$MYDIR
PWD=`pwd`

# Configuration file
CONF=$MYDIR/../etc/nmrproc.conf
[ ! -f $CONF ] && echo "Error $CONF" && exit 1

# Init
. $MYDIR/../etc/nmrproc.conf 2>/dev/null
[ ! -d $ROOTDIR ] && echo "Error $ROOTDIR" && exit 1

BIN=$ROOTDIR/bin
SCRIPTS=$ROOTDIR/scripts
PARSER="$SH $SCRIPTS/$PARSERBRUKER"

INPUT=""
REP=""
DECONV=""
VERBOSE=0
HEADER=0

# Get Cmd line arguments depending on options
while getopts i:o:Dhv opt
do
       case $opt in
       i) INPUT=$OPTARG ;;
       o) REP=$OPTARG ;;
       D) DECONV="-D" ;;
       h) HEADER=1 ;;
       v) VERBOSE=1 ;;
       esac
done

# Check
[ x$INPUT == x ] && echo "Argument -i INPUT missing" && exit 1
[ -z $INPUT -o ! -f $INPUT ] && echo "the file $INPUT is unavailable" && exit 1
[ $VERBOSE -eq 1 ] && echo "$INPUT"

[ x$REP == x ] && echo "Argument -o <directory> missing" && exit 1
[ ! -d $REP ] && echo "$REP: No such directory" && exit 1
[ $VERBOSE -eq 1 ] && echo "$REP"

CNT=`cat $INPUT | head -1 | sed -e "s/[^;]//g" | wc -c`
[ $CNT -lt 2 ] && echo "The sample file format is wrong. Need at least 2 columns." && exit 1
[ $VERBOSE -eq 1 ] && echo "$CNT"

echo "1;Samplecode" > $REP/factors
NBFAC=`expr $CNT - 2`
if [ $HEADER -eq 0 ]; then
   cp $INPUT $REP/samples.csv
   i=1
   while [ $i -le $NBFAC ]; do
       echo $(expr $i + 1)";Factor $i" >> $REP/factors
       i=$(expr $i + 1)
   done
fi
if [ $HEADER -eq 1 ]; then
   tail -`expr $(cat $INPUT | wc -l) - 1` $INPUT > $REP/samples.csv
   HEADS=`cat $INPUT | head -1`
   i=1
   while [ $i -le $NBFAC ]; do
       echo $(expr $i + 1)";"$(echo $HEADS | cut -d';' -f$(expr $i + 2)) >> $REP/factors
       i=`expr $i + 1`
   done
fi
(cd $REP; chmod 644 samples.csv; ln -s samples.csv rawfile)

DIR=`dirname $INPUT`
[ $VERBOSE -eq 1 ] && echo "$DIR"

SPECLST=$REP/list.txt
[ -f $SPECLST ] && rm -f $SPECLST

SPECLST2=$REP/list_1r.txt
[ -f $SPECLST2 ] && rm -f $SPECLST2

OPTVER=""
[ $VERBOSE -eq 1 ] && OPTVER="-v"

CNTTOT=`cat $REP/rawfile | wc -l | tr -d "\n"`
CNT=0
for l in `cat $REP/rawfile`; do
    F1=`echo $l | cut -d';' -f1`
    F2=`echo $l | cut -d';' -f2`
    BRUKER=$F1
    [ ! -f "$DIR/$BRUKER.zip" ] && continue
    CNT=`expr $CNT + 1`
    echo "----------------------------"
    echo "$BRUKER ($CNT/$CNTTOT) ..."
    echo "NAME = $F2"
    $PARSER -i $DIR/$BRUKER -o $REP -a $F2 $DECONV $OPTVER
    RET=$?
    [ $RET -ne 0 ] && echo "Bad" && continue
    [ $RET -eq 0 ] && echo "OK"
    NBPOINTS=`cat $REP/$F2.$RAW | wc -l | tr '\n' ' ' | sed -e "s/ //g"`
    echo "$NBPOINTS;$F2;$REP" >> $SPECLST
    echo "$REP/$F2.$PROC" >> $SPECLST2
done

DIFF=`expr $CNTTOT - $CNT`
[ $DIFF -gt 0 ] && echo "ERROR: $DIFF Bruker directories missing!"

INFOS=`awk -F';' '{count[\$1]++}END{for(j in count) printf("%d %d\n",count[j],j); }' $SPECLST | sort -r | sed -e "s/ /_/g"`

chmod go+rw $REP

NB=`echo $INFOS | wc -w | tr '\n' ' ' | sed -e "s/ //g"`
if [ $NB -ne 1 ]; then
   SIZEREF=`echo $INFOS | cut -d'_' -f2 | cut -d' ' -f1`
   for LINE in `cat $SPECLST`; do
      NBPOINTS=`echo $LINE | cut -d';' -f1`
      SAMPLEID=`echo $LINE | cut -d';' -f2`
      [ "$NBPOINTS" != "$SIZEREF" ] && echo "ERROR: $SAMPLEID has $NBPOINTS points instead of $SIZEREF"
   done
   exit 1
fi

echo -n "Pack ..."
$BIN/$PACK_BIN $SPECLST2 $REP/$SPEC_PACKED 2>/dev/null
RET=$?
[ $RET -ne 0 ] && echo "Bad"
[ $RET -eq 0 ] && echo "OK"

rm -f $REP/*.txt
rm -f $REP/*.par
rm -f $REP/*.model
rm -f $REP/*.log

exit $RET

