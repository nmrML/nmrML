#!/usr/bin/perl

# parse JCAMP-DX files. DATA TYPE= NMR spectrum and DATA CLASS= XYDATA
# recover parameters of experiment (name, number, owner, solvent, ...), spectrum data(intensity) and values to calculate ppm scale
# output : file containing parameters of experiment, ppm and intensities
 
my $PROG_DIR;
BEGIN
{
        $PROG_DIR = $0;
        $PROG_DIR =~ s/[^\/]+$//;
        if ( $PROG_DIR !~ /^\s*\// )
        {
                my $CUR_DIR = `pwd`;
        chomp($CUR_DIR);
                $CUR_DIR =~ s/\/+\s*$//;
                $PROG_DIR =~ s/\.\/*$//;
                $PROG_DIR = "$CUR_DIR/$PROG_DIR";
    }
        $PROG_DIR =~ s/\/+\s*$//;
}
use lib "$PROG_DIR";

use File::Basename;

#################################################################################################

my $JCAMPfile=$ARGV[0];
my $spectrum=$ARGV[1];

open(J,"$JCAMPfile")||die "cannot open $JCAMPfile:$!\n";
open (W,">$spectrum")||die "cannot open $spectrum:$!\n";

my ($DATA_TYPE,$DATA_CLASS,$OWNER,$SOLVENT,$PULPROG,$DATE);
my $NAME="";
my $EXPNO=0;
my $PROCNO=0;
my $OFFSET=0;
my $SF=0;
my $SI=0;
my $SW_p=0;
my %couple=();
my ($interval, $min_ppm, @ppm_scale);
my $INTmax=0;
my $version="";

while (<J>)
{  
    chomp;
    if (!$DATA_TYPE) {if(($DATA_TYPE) = ($_ =~ /^\#\#DATA TYPE=\s(NMR SPECTRUM)/)){if ($DATA_TYPE ne "NMR SPECTRUM") {print W "data type NOK\n";}}}
    if (($DATA_CLASS) = ($_ =~ /^\#\#DATA CLASS=\s(XYDATA)/)){if ($DATA_CLASS ne "XYDATA") {print W "data class NOK\n";}}

    if (!$JCver)   {if(($JCver)= ($_ =~/^\#\#JCAMPDX=\s([^\s]+)\s/)) {print "JCAMP Version=$JCver\n";}}
    if (!$version) {if(($version)= ($_ =~/\$\$\sBruker\sNMR\sJCAMP-DX\s(.+)$/)) {print "Bruker NMR JCAMP-DX Version=$version\n";}}
    if (!$NAME)    {if(($NAME)   = ($_ =~/^\#\#TITLE=(.*)/))       {print "NAME=$NAME\n";}}
    if (!$EXPNO)   {if(($EXPNO)  = ($_ =~/^\#\#\$EXPNO=\s(\d+)/))  {$EXPNO=$1; print "EXPNO=$EXPNO\n";}}
    if (!$PROCNO)  {if(($PROCNO) = ($_ =~/^\#\#\$PROCNO=\s(\d+)/)) {print "PROCNO=$PROCNO\n";}}
    if (!$SI)      {if(($SI)     = ($_ =~/^\#\#\$SI=\s(.+)/))      {print "SI=$SI\n";}}
    if (!$TD)      {if(($TD)     = ($_ =~/^\#\#\$TD=\s(.+)/))      {print "TD=$TD\n";}}
    if (!$SF)      {if(($SF)     = ($_ =~/^\#\#\$SF=\s(.+)/))      {print "SF=$SF\n";}}
    if (!$SW_p)    {if(($SW_p)   = ($_ =~/^\#\#\$SW_p=\s(.+)/))    {print "SW_p=$SW_p\n";}}
    if (!$OFFSET)  {if(($OFFSET) = ($_ =~/^\#\#\$OFFSET=\s(.+)/))  {print "OFFSET=$OFFSET\n";}}

    if ($_ =~/^\#\#XYDATA=\s?\(X\+\+\(Y\.\.Y\)\)/)    {

        $interval=  $SW_p/($SF*($SI - 1));
        $min_ppm = $OFFSET - ($SW_p/$SF);
          $OFFSETtmp=$OFFSET;

         while (<J>) {
            chomp;
            last if  /^\#\#END=/;
            my ($point,$ligne) = ($_ =~ /^\s*(\d*\.?\d+)\s*([-+]?\d+\s*.+)/);            
            while($ligne =~ /^([+-]?)(\d*\.?\d+)\s*(.*)$/) {
                my ($sign,$intensity,$reste) = ($1,$2,$3);
                $intensity = -$intensity if $sign eq '-';
                $INTmax = $intensity>$INTmax ? $intensity : $INTmax;
                print W sprintf ("%8.5f\t%9.4f\n",$OFFSETtmp,$intensity);
                $point--;
                $OFFSETtmp -= $interval;
                $ligne = $reste;
            }
       }
    }
}
print "INT max = $INTmax\n";
print "INTERVAL = $interval\n";
print "min_ppm = $min_ppm\n";


