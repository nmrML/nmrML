#!/bin/bash

MYDIR=`dirname $0` && [ ! `echo "$0" | grep '^\/'` ] && MYDIR=`pwd`/$MYDIR

LOGDIR=$MYDIR/../www/log/tracing
ACCESS=$MYDIR/../www/log/access.log
GEOLOC=http://freegeoip.net/csv

for f in `ls $LOGDIR/*`; do
   ip=`basename $f`
   grep "^$ip" $ACCESS 2>&1 1>/dev/null
   RET=$?
   if [ $RET -eq 1 ]; then
      echo -n "Add $ip ..."
      wget -nv -O - $GEOLOC/$ip | sed -e "s/,/; /g" -e "s/\"//g" >> $ACCESS
      echo OK
   fi
done
 
